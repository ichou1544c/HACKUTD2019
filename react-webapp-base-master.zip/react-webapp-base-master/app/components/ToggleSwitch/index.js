import '@trendmicro/react-toggle-switch/dist/react-toggle-switch.css';

export default from '@trendmicro/react-toggle-switch';
