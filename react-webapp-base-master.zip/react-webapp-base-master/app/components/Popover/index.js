import '@trendmicro/react-popover/dist/react-popover.css';

export default from '@trendmicro/react-popover';
