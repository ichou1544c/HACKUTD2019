import '@trendmicro/react-loader/dist/react-loader.css';
import Loader from '@trendmicro/react-loader';

export default Loader;
