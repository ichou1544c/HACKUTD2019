import '@trendmicro/react-notifications/dist/react-notifications.css';

export {
    Notification,
    ToastNotification
} from '@trendmicro/react-notifications';
