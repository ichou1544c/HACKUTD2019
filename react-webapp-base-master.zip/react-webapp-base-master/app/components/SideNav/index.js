import '@trendmicro/react-sidenav/dist/react-sidenav.css';
import SideNav from '@trendmicro/react-sidenav';

export { Toggle, Nav, NavItem, NavIcon, NavText } from '@trendmicro/react-sidenav';
export default SideNav;
