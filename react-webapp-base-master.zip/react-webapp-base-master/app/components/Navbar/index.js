import '@trendmicro/react-navbar/dist/react-navbar.css';
import Navbar from '@trendmicro/react-navbar';

export default Navbar;
