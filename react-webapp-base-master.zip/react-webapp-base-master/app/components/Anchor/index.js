import Anchor from '@trendmicro/react-anchor';

export default Anchor;
