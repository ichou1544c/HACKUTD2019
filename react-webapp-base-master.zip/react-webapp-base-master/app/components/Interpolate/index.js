import Interpolate from '@trendmicro/react-interpolate';

export default Interpolate;
