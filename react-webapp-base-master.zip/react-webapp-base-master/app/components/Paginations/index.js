import '@trendmicro/react-paginations/dist/react-paginations.css';

export {
    TablePagination
} from '@trendmicro/react-paginations';
