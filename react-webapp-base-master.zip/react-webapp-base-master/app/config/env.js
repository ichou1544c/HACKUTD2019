module.exports = {
    ...process.env
};
