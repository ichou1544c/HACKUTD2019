import restful from './restful';
import graphql from './graphql';

export default {
    restful,
    graphql
};
