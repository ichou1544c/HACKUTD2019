module.exports = {
    languages: [
        'en' // English (default)
    ]
};
