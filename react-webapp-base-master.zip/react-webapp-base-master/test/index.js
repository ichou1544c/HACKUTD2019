import { test } from 'tap';

test('noop', (t) => {
    t.end();
});
